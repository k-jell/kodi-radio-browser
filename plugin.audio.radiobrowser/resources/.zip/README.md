# radio-browser.info plugin for kodi
* https://kodi.tv/
* https://kodi.tv/addon/music-add-ons-plugins/radio-browserinfo